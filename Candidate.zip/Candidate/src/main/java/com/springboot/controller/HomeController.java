package com.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.Candidate;
import com.springboot.repository.CandidateRepository;
@Controller
public class HomeController {
	

@RequestMapping("/home")
	
	public String indexjsp() {
		return "index";
		
	}


@RequestMapping("/login")
	
	public String loginjsp() {
		return "login";
		
	}
@RequestMapping("/succes")

public String succesjsp() {
	return "success";
	
}

@RequestMapping("/success")

public String successjsp() {
	return "success";
	
}
@RequestMapping("/viewall")

public String viealljsp() {
	return "viewall";
	
}

@RequestMapping(value="login",method = RequestMethod.GET)

public String loginPage() {

     return "login";

}



@RequestMapping(value="login",method = RequestMethod.POST)

public String gotosuccesPage(@RequestParam String name, 

          ModelMap model) {

     model.put("name", name);

     return "success";

}


//@Autowired
//private CandidateRepository candidateRepository;
//
//@PostMapping("/addCandidate")
//public String saveStudent(@RequestBody Candidate candidate) {
//	candidateRepository.save(candidate);
//	return "Added Candidate with name :" + candidate.getName();
//}
//
//@GetMapping("/findAllCandidates")
//public List<Candidate> getCandidates() {
//	return candidateRepository.findAll();
//}
}
