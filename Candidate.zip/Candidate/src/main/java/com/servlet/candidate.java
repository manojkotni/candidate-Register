package com.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class candidate {
	private static final long serialVersionUID = 1L;
    
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String candidateName = request.getParameter("candidateName");
		String contactNumber = request.getParameter("contactNumber");
		String gender = request.getParameter("gender");
		String positionApplied = request.getParameter("positionApplied");
		String expectedSalary = request.getParameter("expectedSalary");
		String yearsOfExperience = request.getParameter("yearsOfExperience");
		
		if(candidateName.isEmpty() || contactNumber.isEmpty() || gender.isEmpty() || 
				positionApplied.isEmpty() || expectedSalary.isEmpty() || yearsOfExperience.isEmpty())
		{
			RequestDispatcher req = request.getRequestDispatcher("login.jsp");
			req.include(request, response);
		}
		else
		{
			RequestDispatcher req = request.getRequestDispatcher("error.jsp");
			req.forward(request, response);
		}
	}

}
